﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Data.SqlClient;
using System.Speech.Synthesis;
using System.Threading.Tasks;
using 图书借还系统;

namespace 图书借还系统
{
    public partial class Form1 : Form
    {
        public string strValue = string.Empty;


        public Form1()
        {
            InitializeComponent();
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;//设置该属性 为false
           
        }


        /* 新增自定义函数：更新可用串口 */
        private void Updata_Serialport_Name(ComboBox MycomboBox)
        {
            string[] ArryPort;                               // 定义字符串数组，数组名为 ArryPort
            ArryPort = SerialPort.GetPortNames();            // SerialPort.GetPortNames()函数功能为获取计算机所有可用串口，以字符串数组形式输出
            MycomboBox.Items.Clear();                        // 清除当前组合框下拉菜单内容                  
            for (int i = 0; i < ArryPort.Length; i++)
            {
                MycomboBox.Items.Add(ArryPort[i]);           // 将所有的可用串口号添加到端口对应的组合框中
            }
        }
        private void BForm_Load(object sender, EventArgs e)
        {
            Updata_Serialport_Name(comboBox1); // 调用更新可用串口函数，comboBox1为端口号组合框的名称

        }
        private void button1_Click(object sender, EventArgs e)
        {

            if (button1.Text == "打开串口")                                  // 如果当前是串口设备是关闭状态
            {
                try                                                          // try 是尝试部分，如果尝试过程中出现问题，进入catch部分，执行错误处理代码  
                {
                    serialPort1.PortName = comboBox1.Text;                   // 将串口设备的串口号属性设置为comboBox1复选框中选择的串口号
                    serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text);  // 将串口设备的波特率属性设置为comboBox2复选框中选择的波特率
                    serialPort1.Open();                                      // 打开串口，如果打开了继续向下执行，如果失败了，跳转至catch部分
                    comboBox1.Enabled = false;                               // 串口已打开，将comboBox1设置为不可操作
                    comboBox2.Enabled = false;                               // 串口已打开，将comboBox2设置为不可操作
                    button1.BackColor = Color.Red;                           // 将串口开关按键的颜色，改为红色
                    button1.Text = "关闭串口";                               // 将串口开关按键的文字改为“关闭串口”
                }
                catch
                {
                    MessageBox.Show("打开串口失败，请检查串口", "错误");     // 弹出错误对话框
                }
            }
            else                                             // 如果当前串口设备是打开状态
            {
                try
                {
                    serialPort1.Close();                     // 关闭串口
                    comboBox1.Enabled = true;                // 串口已关闭，将comboBox1设置为可操作
                    comboBox2.Enabled = true;                // 串口已关闭，将comboBox2设置为可操作
                    button1.BackColor = Color.Lime;          // 将串口开关按键的颜色，改为青绿色
                    button1.Text = "打开串口";               // 将串口开关按键的文字改为“打开串口”
                }
                catch
                {
                    MessageBox.Show("关闭串口失败，请检查串口", "错误");   // 弹出错误对话框
                }
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Updata_Serialport_Name(comboBox1);   // 定时刷新可用串口，可以保证在程序启动之后连接的设备也能被检测到
         //   textBox1.Clear();
        }


        //
        public Action<string> action;

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            // 读取串口缓存中的数据
            string data = serialPort1.ReadExisting();
           
            

            // 把读取到的数据转换为 16 进制格式
            StringBuilder hex = new StringBuilder(data.Length * 3);
            foreach (char c in data)
            {
                hex.AppendFormat("{0:X2} ", Convert.ToInt32(c));
            }
            
            
            // 把转换后的数据显示在文本框中
            Invoke((MethodInvoker)(() => {
                textBox1.AppendText(hex.ToString());
            }));
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            Form2 form2= new Form2();
            form2.Show();
         //   await Task.Delay(2000);
            SpeechSynthesizer synth = new SpeechSynthesizer();
            this.Hide();
            synth.Speak("请刷学生卡或输入账号密码登录");
           
            
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
