﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Data.SqlClient;
using System.Configuration;
using System.Speech.Synthesis;
namespace 图书借还系统
{
    public partial class Form4 : Form
    {
        public delegate void CloseSerialPortDelegate();
        public SerialPort serialPort;
        private Form2 form2;
        public event CloseSerialPortDelegate CloseSerialPortEvent;
        private SqlConnection sqlConnection;
        private string dataBuffer;

        public delegate void SerialDataReceivedEventHandler(string data);
        SpeechSynthesizer synth = new SpeechSynthesizer();

        public Form4(Form2 form)
        {
            InitializeComponent();
            synth.Volume = 100;
            synth.Rate = 0;
            form2 = form;
            form2.SerialDataReceived += Form2_SerialDataReceived;

        }

       

        public Form4()
        {
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (CloseSerialPortEvent != null)
            {
                CloseSerialPortEvent();
            }
        }



        //串口数据
        private void Form2_SerialDataReceived(string data)
        {
            // 将串口数据赋值给 data 变量
            data = data;
            StringBuilder hex = new StringBuilder(data.Length * 3);
            foreach (char c in data)
            {
                hex.AppendFormat("{0:X2} ", Convert.ToInt32(c));
            }


            // 把转换后的数据显示在文本框中
            Invoke((MethodInvoker)(() =>
            {
                textBox1.AppendText(hex.ToString());
            }));
        }
            private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Application.Restart();
           


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DAO dao = new DAO();
            string id = textBox1.Text;
            DateTime today = DateTime.Today;
            DateTime returnDate = today.AddDays(30);

            string connectionString = ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString;
            string selectQuery = "SELECT * FROM book WHERE id = '" + id + "'";
            IDataReader dc = dao.read(selectQuery);
            if (dc.Read())
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(selectQuery, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    if (table.Rows.Count > 0)   // 如果找到相应的记录
                    {
                        int number = int.Parse(table.Rows[0]["number"].ToString());   // 获取相应的数字值
                        if (number > 0)
                        {

                            number--;    // 数字值减一
                                         // 更新该行数据
                            string updateQuery = "UPDATE book SET number = " + number.ToString() + " WHERE id = '" + id + "'";
                            SqlCommand command = new SqlCommand(updateQuery, connection);
                            command.ExecuteNonQuery();
                            //   MessageBox.Show("借阅成功，还书日期 " + returnDate.ToShortDateString());
                            synth.Speak("借阅成功，还书日期" + returnDate.ToShortDateString());
                        }
                        else
                        {
                            synth.Speak("借阅失败,请联系管理员");
                            //  MessageBox.Show("借阅失败");
                        }
                    }
                }
            }
            else
            {
                synth.Speak("借阅失败,请放入正确的图书");
            }

            // 刷新 DataGridView 控件中的数据
            try
            {
                DataTable dataTable = new DataTable();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT * FROM book", sqlConnection);
                sqlDataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            textBox1.Text = string.Empty;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: 这行代码将数据加载到表“图书系统DataSet.book”中。您可以根据需要移动或删除它。
            this.bookTableAdapter.Fill(this.图书系统DataSet.book);
            // TODO: 这行代码将数据加载到表“图书系统DataSet.book”中。您可以根据需要移动或删除它。
            this.bookTableAdapter.Fill(this.图书系统DataSet.book);
            string connectionString = @"Data Source=DESKTOP-TDN9U53;Initial Catalog=图书系统;Integrated Security=True;";
            sqlConnection = new SqlConnection(connectionString);
            // 查询所有记录并填充到 DataTable 对象中

            DataTable dataTable = new DataTable();
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("SELECT * FROM book", sqlConnection);
            sqlDataAdapter.Fill(dataTable);

            // 将 DataTable 对象绑定到 DataGridView 控件上
            dataGridView1.DataSource = dataTable;
            //TODO
        }

        
        private void timer1_Tick(object sender, EventArgs e)
        {
          //  textBox1.Text = null;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
