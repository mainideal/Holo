﻿
using System.Data.SqlClient;


namespace 图书借还系统
{

    class DAO
    {
        SqlConnection sc = new SqlConnection();
        public SqlConnection connect()
        {
            string str = @"Data Source=DESKTOP-TDN9U53;Initial Catalog=图书系统;Integrated Security=True;";
            sc = new SqlConnection(str);
            sc.Open();
            return sc;
        }
        public SqlCommand command(string sql)
        {
            SqlCommand cmd = new SqlCommand(sql, connect());
            return cmd;

        }
        public int Execute(string sql)
        {
            return command(sql).ExecuteNonQuery();
        }
        public SqlDataReader read(string sql)
        {
            return command(sql).ExecuteReader();
        }
        public void DAOClose()
        {
            sc.Close();
        }
    }
}