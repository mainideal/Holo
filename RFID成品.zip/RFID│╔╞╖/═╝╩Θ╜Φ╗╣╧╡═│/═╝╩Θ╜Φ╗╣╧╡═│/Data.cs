﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 图书借还系统
{
    class Data
    {
        public static string UID = "sa", pwd = "200225";
    }
}
