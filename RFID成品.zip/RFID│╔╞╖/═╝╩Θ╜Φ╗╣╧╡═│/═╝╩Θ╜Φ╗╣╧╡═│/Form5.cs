﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Data.SqlClient;
using System.Configuration;
using System.Speech.Synthesis;
namespace 图书借还系统
{
    public partial class Form5 : Form
    {
        public delegate void CloseSerialPortDelegate();
        public SerialPort serialPort;
        private Form2 form2;
        public event CloseSerialPortDelegate CloseSerialPortEvent;
        private SqlConnection sqlConnection;
        private string dataBuffer;
        SpeechSynthesizer synth = new SpeechSynthesizer();
        public object bookTableAdapter { get; private set; }
        public object 图书系统DataSet { get; private set; }

        public delegate void SerialDataReceivedEventHandler(string data);
        public Form5(Form2 form)
        {
            InitializeComponent();
            form2 = form;
            form2.SerialDataReceived += Form2_SerialDataReceived;
            synth.Volume = 100;
            synth.Rate = 0;
        }
        //串口数据
        private void Form2_SerialDataReceived(string data)
        {
            // 将串口数据赋值给 data 变量
            data = data;
            StringBuilder hex = new StringBuilder(data.Length * 3);
            foreach (char c in data)
            {
                hex.AppendFormat("{0:X2} ", Convert.ToInt32(c));
            }


            // 把转换后的数据显示在文本框中
            Invoke((MethodInvoker)(() =>
            {
                textBox1.AppendText(hex.ToString());
            }));
        }
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void date()
        {
            if (textBox1.Text != "")
            {
                string id = textBox1.Text;
                string connectionString = ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString;
                string selectQuery = "SELECT * FROM book WHERE id = '" + id + "'";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(selectQuery, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    if (table.Rows.Count > 0)   // 如果找到相应的记录
                    {

                        string name = table.Rows[0]["name"].ToString();   // 获取 name 列的值
                        DateTime time = DateTime.Now;   // 获取比对时的时间信息
                                                        // 更新该行数据
                                                        //  string updateQuery = "UPDATE book SET number = " + number.ToString() + " WHERE id = '" + id + "'";
                                                        //  SqlCommand command = new SqlCommand(updateQuery, connection);
                                                        //    command.ExecuteNonQuery();
                                                        // 将比对结果添加到 DataGridView 中
                        dataGridView1.Rows.Add(id, name, time.ToString());
                    }
                }
              //  timer1.Stop();
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            //  textBox1.Text = null;
            if (dataGridView1.Rows.Count == 0)
            {
                date();
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            
                string connectionString = @"Data Source=DESKTOP-TDN9U53;Initial Catalog=图书系统;Integrated Security=True;";
                sqlConnection = new SqlConnection(connectionString);
               
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string id = textBox1.Text;

           // MessageBox.Show("欢迎还书");

            string connectionString = ConfigurationManager.ConnectionStrings["MyConnectionString"].ConnectionString;
            string selectQuery = "SELECT * FROM book WHERE id = '" + id + "'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(selectQuery, connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                if (table.Rows.Count > 0)   // 如果找到相应的记录
                {
                    int number = int.Parse(table.Rows[0]["number"].ToString());   // 获取相应的数字值
                    number++;    // 数字值加一
                    string name = table.Rows[0]["name"].ToString();   // 获取 name 列的值
                    DateTime time = DateTime.Now;   // 获取比对时的时间信息
                                                    // 更新该行数据
                    string updateQuery = "UPDATE book SET number = " + number.ToString() + " WHERE id = '" + id + "'";
                    SqlCommand command = new SqlCommand(updateQuery, connection);
                    command.ExecuteNonQuery();
                    // 将比对结果添加到 DataGridView 中
                    //    dataGridView1.Rows.Add(id, name, time.ToString());
                    synth.Speak("还书成功");
                    textBox1.Text = null;
                    dataGridView1.Rows.Clear();
                }
                else
                {
                    synth.Speak("还书失败，请放入正确的图书");
                    textBox1.Text = null;
                }
            }
        }
    }
}
