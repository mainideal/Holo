﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Speech.Synthesis;
using System.Data.SqlClient;
using System.Configuration;
using System.Threading;
namespace 图书借还系统
{
    public partial class Form2 : Form
    {
          public SerialPort serialPort;
        private Form4 form4;
       

        public delegate void SerialDataReceivedEventHandler(string data);
          public event SerialDataReceivedEventHandler SerialDataReceived;
        SpeechSynthesizer synth = new SpeechSynthesizer();
        PromptBuilder builder = new PromptBuilder();
        // synth.Volume = 100;
        //     synth.Rate = 0;
        public Form2()
        {
            InitializeComponent();
      //语音
            synth.Volume = 100;
            synth.Rate = 0;
            builder.StartVoice(VoiceGender.Neutral, VoiceAge.Senior);

            builder.AppendText("登录失败，请检查账号或密码");
            builder.EndVoice();
            
            serialPort = new SerialPort("COM5", 9600, Parity.None, 8, StopBits.One);
                serialPort.DataReceived += serialPort_DataReceived;
            if (serialPort != null)
            {
                if (serialPort.IsOpen)
                {
                    serialPort.DiscardInBuffer();
                    serialPort.Close();
                }
                else
                {
                    serialPort.Open();
                   
                }
            }

         //  
        }

        public void CloseSerialPort()
        {
            if (serialPort != null && serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
            {
                //刷卡
                login2();
            }
            else  if (textBox1.Text != "" && textBox2.Text != "")
            {
              //账号密码
                 login();
             //   this.Hide();
            }
            else
            {
                synth.Speak("输入有空项，请重新输入");
               // MessageBox.Show("输入有空项，重新输入");
                
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
            {
                login1();
            }
            else if (textBox1.Text != "" && textBox2.Text != "")
            {
                //  Form5 form5 = new Form5(this);
                //  form5.Show();
                login4();
                //  this.Hide();
            }
            else
            {
                synth.Speak("输入有空项，请重新输入");
              //  MessageBox.Show("输入有空项，重新输入");
            }
        }
        //数据库

        public void login()
        {
            DAO dao = new DAO();
             
                 string sql = $"select * from tuser where userid='{textBox1.Text}' and password='{textBox2.Text}' or id='{textBox3.Text}'";
                IDataReader dc = dao.read(sql);
                if (dc.Read())
                {
                string name = dc.GetString(dc.GetOrdinal("name"));
                synth.Speak("欢迎您" + name);
                Form4 form4 = new Form4(this);
                    form4.Show();
                    this.Close();
                }
                else
                {
                //    MessageBox.Show("登录失败");
                synth.Speak(builder);
                textBox3.Text = null;
                textBox2.Text = null;
                textBox1.Text = null;
            }
           
           
                dao.DAOClose();
         }
        public void login4()
        {
            DAO dao = new DAO();
            
                string sql = $"select * from tuser where userid='{textBox1.Text}' and password='{textBox2.Text}' or id='{textBox3.Text}'";
                IDataReader dc = dao.read(sql);
                if (dc.Read())
                {
                string name = dc.GetString(dc.GetOrdinal("name"));
                synth.Speak("欢迎您" + name);
              //  MessageBox.Show("登录成功" + name);
                    Form5 form5 = new Form5(this);
                    form5.Show();
                    this.Hide();

                }
                else
                {
                    
                synth.Speak(builder);
                textBox3.Text = null;
                textBox2.Text = null;
                textBox1.Text = null;
            }
            
            /*管理界面
            if (guanli.Checked == true)
            {
                //   DAO dao = new DAO();
                string sql = $"select * from tuser where id='{textBox3.Text}'";
                IDataReader dc = dao.read(sql);
                if (dc.Read())
                {
                    MessageBox.Show("登录成功");
                    Form3 form3 = new Form3();
                    form3.Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("登录失败");

                }
            }
            */

            dao.DAOClose();
        }




        public void login1()
        {
            DAO dao = new DAO();
           
            
                 string sql = $"select * from tuser where  id='{textBox3.Text}'";
                    IDataReader dc = dao.read(sql);
                    if (dc.Read())
                    {
                string name = dc.GetString(dc.GetOrdinal("name"));
                synth.Speak("欢迎您" + name);
                Form5 form5 = new Form5(this);
                        form5.Show();
                        this.Hide();
                    }
                    else
                    {
                      //  MessageBox.Show("登录失败");
                synth.Speak("登录失败,请刷正确卡");
                textBox3.Text = null;
            }
                
               
            
            dao.DAOClose();

        }

        public void login2()
        {
            DAO dao = new DAO();

            string sql = $"select * from tuser where id='{textBox3.Text}'";
            IDataReader dc = dao.read(sql);

            if (dc.Read())
            {
                // 如果找到匹配项，输出该行的 name 列值
                string name = dc.GetString(dc.GetOrdinal("name"));
               // MessageBox.Show($"登录成功，用户名为 {name}");
                synth.Speak("欢迎登录" + name);
                Form4 form4 = new Form4(this);
                form4.Show();
                this.Hide();
            }
            else
            {
                synth.Speak("登录失败，请刷正确卡");
                textBox3.Text = null;
            }

            dao.DAOClose();
        }

        private void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            // 处理串口数据
            // 读取串口缓存中的数据
            string data = serialPort.ReadExisting();
            // Form3.ReceivedData = textBox1.Text;
            SerialDataReceived?.Invoke(data);
           
            // 把读取到的数据转换为 16 进制格式
            StringBuilder hex = new StringBuilder(data.Length * 3);
            foreach (char c in data)
            {
                hex.AppendFormat("{0:X2} ", Convert.ToInt32(c));
            }
            // 把转换后的数据显示在文本框中
            Invoke((MethodInvoker)(() => {
                textBox3.AppendText(hex.ToString());
            }));
            
           
            

        }

        

        



        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
       

        private void Form2_Load(object sender, EventArgs e)
        {
          
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
